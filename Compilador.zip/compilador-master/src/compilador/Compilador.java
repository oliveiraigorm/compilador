package compilador;

import java.io.*;
import java.util.Scanner;
import lexico.Lexico;
import lexico.LexicoException;

public class Compilador {

    public static void main(String[] args) throws IOException, LexicoException{

        System.out.print("Digite o nome do arquivo: ");
        Scanner nome = new Scanner (System.in);     
        String arquivo = nome.next();
       
       
        Lexico lexico = new Lexico(arquivo);
        lexico.scan();
    }
}   
