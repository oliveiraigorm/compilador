/*
 *Mensagem de excessão para o Analisador Lexico
 */
package lexico;

public class LexicoException extends Exception{
    public LexicoException(String msg) {
        super(msg);
    }    
}
